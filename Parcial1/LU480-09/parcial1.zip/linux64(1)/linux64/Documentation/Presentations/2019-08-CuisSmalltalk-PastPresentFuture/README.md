# Cuis Smalltalk - Past, Present and Future

[Presentation](https://www.youtube.com/watch?v=AkZ9zOzrn_w) given by Hernán and Juan at the [Smalltalks 20019](https://smalltalks2019.fast.org.ar) conference at Neuquén.
