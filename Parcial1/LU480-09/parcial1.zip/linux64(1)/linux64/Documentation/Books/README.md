# The Cuis Smalltalk Book

The Cuis Smalltalk Book, written by Hilaire Fernandes with Ken Dickey and Juan Vuletich.

You can read it [online](https://cuis-smalltalk.github.io/TheCuisBook) or download the [pdf version](https://github.com/Cuis-Smalltalk/TheCuisBook/releases/download/latestpdfbuild/TheCuisBook.pdf)
