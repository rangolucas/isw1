#!/bin/bash
vmLiveTyping-ARM/squeak CuisUniversity-5981.image