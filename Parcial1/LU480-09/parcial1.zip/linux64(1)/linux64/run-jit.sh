#!/bin/bash
vm-jit/squeak CuisUniversity-5981.image