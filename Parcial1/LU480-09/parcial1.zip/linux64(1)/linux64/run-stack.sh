#!/bin/bash
vmLiveTyping-Stack/squeak CuisUniversity-5981.image