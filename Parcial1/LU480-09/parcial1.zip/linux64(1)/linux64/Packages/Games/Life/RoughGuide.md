Cuis-Smalltalk-life
==========================
Techniques of Interest



- A view creating another view

- Model is independent of the views

- Example of changing one view having no effect on other views

- Use of #when:send:to: and #triggerEvent: for communication between view and model (Observer Pattern)

- Each cell of the grid is a morph

- Need for popup menu signaled by grid morphs
  