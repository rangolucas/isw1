#!/bin/bash
vmLiveTyping/squeak CuisUniversity-5981.image